double round6(double d);
int findstring(char* str1,char* str2);
int findstring2(char* str1,char* str2);
long trunc2int(char total[], char left[], char right[]);
long trunc2int2(char total[], char left[], char right[]);
long trunc2int3(char total[], char left[], char right[]);
int getnewnodeid(long oldnodeid);
double trunc2float(char total[], char left[], char right[]);
void dijkstra(long src);
int minDistance(long src,int sptSet[]);
int isalonenode(int newnodeid);

