void initial();
void readmapfile();
void writemapfile();
