int writePath(int inputnode1,int inputnode2);
void printMap();
